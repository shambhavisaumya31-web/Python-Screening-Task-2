# Python Screening Task 2

## Task Objective
The goal of this task is to create a natural-language prompt that instructs an AI debugging assistant to help students debug their Python code without revealing the full solution.

---

## Final Prompt
See [prompt.txt](./prompt.txt) for the full prompt.

---

## Reasoning & Design Choices

### Why I worded it this way
- Clear **boundaries** were set (“do not provide the corrected code”) to prevent revealing answers.
- Emphasis is on **guidance and hints** rather than direct fixes.
- Encourages a **teaching/mentoring approach** to debugging.

### How I ensured it avoids giving the solution
- Explicit instructions: *“Do not directly provide the corrected solution or final code.”*
- Focus on **hints, suggestions, and debugging strategies** only.

### How it encourages student-friendly feedback
- Supportive and encouraging tone ensures students feel guided, not criticized.
- Promotes **learning by discovery** through hints and debugging methods.

---

## Reasoning (Required Answers)

### What tone and style should the AI use?
The AI should use a **supportive, encouraging, and mentor-like tone** with simple, clear explanations.

### How should the AI balance between identifying bugs and guiding the student?
The AI should:
1. **Identify** possible problem areas (e.g., a suspicious line of code).
2. **Guide** using hints or probing questions.
3. **Encourage** the student to find the fix themselves.

### How would you adapt this prompt for beginner vs. advanced learners?
- **Beginners**: Use simple language, explain concepts step by step, give direct hints (e.g., variable naming, syntax checks).  
- **Advanced learners**: Offer higher-level strategies (e.g., handling edge cases, algorithm efficiency) without overexplaining basics.

---

## Repository Structure

```
python-screening-task-2/
│
├── README.md   # Contains reasoning and explanation
└── prompt.txt  # Contains only the final debugging prompt
```

---

✅ Checklist:
- [x] Prompt is clear and specific  
- [x] Reasoning is thoughtful and well-articulated  
- [x] Tone/style/guidance balance explained  
- [x] Beginner vs. advanced adaptation included  
